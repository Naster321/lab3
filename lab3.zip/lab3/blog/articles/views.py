from articles import models
from django.shortcuts import render
from articles.models import Article


def archive(reguest):
    return render(reguest, 'archive.html', {"posts": Article.object.all()})

# Create your views here.
